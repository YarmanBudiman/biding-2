<?php 

$conn= new mysqli('localhost','root','','bids')or die("Could not connect to mysql".mysqli_error($con));
