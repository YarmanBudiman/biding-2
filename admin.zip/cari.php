<html>
		<head>
		
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
			<title>My Spare Part</title>
			<link rel="stylesheet" href="css/bootstrap.min.css">
            <link rel="stylesheet" href="css/aos.css">
            <link rel="stylesheet" href="css/style.css">
		</head>
		<body bgcolor="WHITE" text="BLACK"  >
</body>
</html>
<?php
	include 'config.php';  	
	$cari=$_GET['cari'];
	if (empty($cari)) {exit();};
    $sql = "select noidpartno,PartName,NoRack,LastStock,Maker from t_sub_material where PartName like '%$cari%' or NoRack like '%$cari%' or Maker like '%$cari%' or noidpartno like '%$cari%' order by PartName ";
	$query = mysqli_query($conn, $sql);

	if (!$query) {
		echo "gagal";
		die ('SQL Error: ' . mysqli_error($conn));
	}
	
	 
	echo  '
      <div class="container">
        <div class="row" > ';	
	while ($row = mysqli_fetch_array($query))
{
	 echo '  <div class="col-6 .col-sm-6 border rounded pl-lg-7" >
	        <a href="gbr/'.$row['noidpartno'].'.jpg">
            <img  src="thumb/'.$row['noidpartno'].'.jpg" alt="No Image" height="100" class="mx-auto d-block"><br>
            </a>
            <strong class="font-weight-normal"><b>'.$row['PartName'].'</b></strong><br>
            <strong class="text-dark" ><font color="red"> <b>'.$row['NoRack'].'</b></font></strong><br>
            <strong class="text-dark ">Maker :'.$row['Maker'].'</strong><br>
            <strong class="text-dark "><font color="green"> Stock :'.$row['LastStock'].'</font></strong>
            <br>
          </div> 
            ';

}	
 	echo '</div>
      </div>
    ';
	mysqli_free_result($query);
	mysqli_close($conn);
?>


 