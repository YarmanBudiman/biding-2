<html>
		<head>
			<title>Cek Tagihan</title>
				<style>
				body {font-family:tahoma, arial; font-size: 16px}	
			</style>
			<link rel="stylesheet" type="text/css" href="pulsa/css/main.css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">	
		</head>

		<body bgcolor="WHITE" text="BLACK"  >
		<FORM ACTION="" METHOD="GET" NAME="input">
		          
		</FORM> 
</body>
</html>
<?php
	include 'config.php';  	
	$pelanggan=$_GET['nama'];
	echo	" Tagihan : <b> ".ucfirst($pelanggan) ." </b> <br>";
    
    $sql = "SELECT id,Tgljual,nama,nohp,hargajual,status from penjualan where nama='$pelanggan' and status='Tagihan' order by Tgljual";
	
	$query = mysqli_query($conn, $sql);

	if (!$query) {
		echo "gagal";
		die ('SQL Error: ' . mysqli_error($conn));
	}
	
	echo '<div class="table100"> <table>	
			<thead class="table100-head">
				<tr>
					<th>Tanggal</th>
					<th>Nomor HP</th>
					<th>Harga</th>
				</tr>
			</thead>';
		
	while ($row = mysqli_fetch_array($query))
{
	echo '<tr>
			<td>'.date('d-M-y', strtotime($row['Tgljual'])).'</td>
			<td>'.$row['nohp'].'</td>
			<td align = "right">'.number_format($row['hargajual'], 0, ',', '.').'</td>
		</tr>';
}	
 	echo "<br></table>";

 	$sql = "SELECT sum(hargajual) as tagih from penjualan  where status='Tagihan' and nama='$pelanggan'";
    $query = mysqli_query($conn, $sql);
    	
	if (!$query) { 	die ('SQL Error: ' . mysqli_error($conn));	}
    $row = mysqli_fetch_array($query);
    echo	"<p align=right >  <b>Total   :  ".number_format($row['tagih'], 0, ',', '.').' </b></p>';

	mysqli_free_result($query);
	mysqli_close($conn);
	echo "<hr>";
	echo "<p>No Rekening : 1320004635653 </p>";
	echo "<p>Bank Mandiri an : Heri Purwanto </p> <br>";
?>